import locatable
import movable
import player_controllable
import frog
import dodgeable
import race_car
import dozer
import truck
import car
import rideable
import log
import turtle
import alligator
import immovable
import touchable
import home
import stage
import road
import untouchable
import water
import grass

if __name__ == "__main__":
    locatable.test()
    movable.test()
    player_controllable.test()
    frog.test()
    dodgeable.test()
    race_car.test()
    dozer.test()
    truck.test()
    car.test()
    rideable.test()
    log.test()
    turtle.test()
    alligator.test()
    immovable.test()
    touchable.test()
    home.test()
    stage.test()
    road.test()
    untouchable.test()
    water.test()
    grass.test()
