#!/usr/bin/python3

from pong_functions import new_game
from one_player import one_player_loop
from two_player import two_player_loop
import pygame
from pygame.locals import *



new_game()

#one_player_loop()

two_player_loop()

